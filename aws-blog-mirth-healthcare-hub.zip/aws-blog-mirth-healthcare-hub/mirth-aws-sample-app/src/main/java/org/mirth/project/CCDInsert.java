package org.mirth.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.JSONObject;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;


/**
 * Mirth Connect, AWS sample integrations
 *
 */
public class CCDInsert 
{
	private static final String DB_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static final String DB_CONNECTION = "jdbc:sqlserver://localhost:1433;DatabaseName=";
	private static final String DB_USER = "mirth_ccd";
	private static final String DB_PASSWORD = "Dallas2017";
	private static final Logger logger = Logger.getLogger(CCDInsert.class);
	
    public static void main( String[] args ) {
	}

    public static void insertToMirthCCD(String ccdJson) {
    	//sqlServerInsertJson(ccdJson, "MIRTH_CCD" );
    	sqlServerInsertJson(ccdJson, "CBP_CMS_TEST_E" );
    }
    
    public static void insertTOCBPCMS(String ccdJson){
    	//sqlServerInsertJson(ccdJson, "CBP_CMS_SAMPLE");
    	sqlServerInsertJson(ccdJson, "CBP_CMS_TEST_E" );
    }
    
    
    
    public static void sqlServerInsertJson(String ccdJson, String dbName) {
        logger.info( "Performing insert into SQL Server DB" );
        try {
        ccdJson = ccdJson.replace("'","");	
        JSONObject obj = new JSONObject(ccdJson);

        JSONObject dataObject = obj.getJSONObject("data");
        JSONObject header = dataObject.getJSONObject("header");
        JSONArray identifierArray = header.getJSONArray("identifiers");
        JSONObject identifierObject = (JSONObject) identifierArray.get(0);
        String memberId = identifierObject.getString("extension");
        
        insertRecordIntoCCDTable(Integer.parseInt(memberId), obj, dbName);
        
        } catch (JSONException e) {logger.error("JSON ERROR"+ e.getMessage()); }
        catch (SQLException sqlEx) { logger.info("SQL Exception ERROR"+ sqlEx.getMessage()); }

    }
    
	private static void insertRecordIntoCCDTable(int memeberId, JSONObject object, String dbName) throws SQLException {

		Connection dbConnection = null;
		Statement statement = null;
		
		int version = getExistingVersion(memeberId, dbName);
		
		if ( version == -1){
			 version = 1;
		}else{
			version = version + 1;
		}
		
		String insertTableSQL = "INSERT INTO dbo.PATIENT_CCD"
				+ "(member_id, value, version, created_date, updated_date) " + " VALUES ("
				+ memeberId + ", '" + object + "' , " + version  + " , CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)";

		try {
			dbConnection = getDBConnection(dbName);
			statement = dbConnection.createStatement();
			logger.info(insertTableSQL);
			// execute insert SQL stetement
			statement.executeUpdate(insertTableSQL);
			logger.info("Record is inserted into CCD Table table!");

		} catch (SQLException e) {
			logger.error(e.getMessage());
		} finally {

			if (statement != null) {
				statement.close();
			}

			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}

	private static int getExistingVersion(int patientId, String dbName) throws SQLException {
		int version = -1;
		
		Connection dbConnection = null;
		Statement stmt = null;
		
		String sql = "select max(version) as version from dbo.PATIENT_CCD where member_id = " + patientId ;
		try{

			dbConnection = getDBConnection(dbName);
			stmt = dbConnection.createStatement();
			ResultSet rs = stmt.executeQuery(sql);	
			
			if(rs != null && rs.next()) {
				version = rs.getInt("version");
			}
		}
		 catch (SQLException e) {
				logger.error(e.getMessage());
				throw e;
			} finally {

				if (stmt != null) {
					stmt.close();
				}

				if (dbConnection != null) {
					dbConnection.close();
				}
			}
		
		return version;
	}
	
    private static Connection getDBConnection(String dbName) {
		Connection dbConnection = null;
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			logger.error(e.getMessage());
		}

		try {
			dbConnection = DriverManager.getConnection(DB_CONNECTION + dbName, DB_USER,DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return dbConnection;

	}

}
