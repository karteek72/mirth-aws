package org.mirth.project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class SampleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CCDInsert mcaws = new CCDInsert();
		mcaws.insertTOCBPCMS(readFile());
	}

	
	private static String readFile() {
		String jsonData = "";
		BufferedReader br = null;
		try {
			String line;
			br = new BufferedReader(new FileReader("C:/mirth/app/bb/output/96115.json"));
			while ((line = br.readLine()) != null) {
				jsonData += line ;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		
		return jsonData;
	}
}
